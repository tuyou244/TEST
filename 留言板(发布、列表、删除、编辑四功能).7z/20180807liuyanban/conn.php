<meta charset="utf8">
<?php
$conn=mysqli_connect('localhost','root','root');
mysqli_query($conn, 'use board');
mysqli_query($conn, 'set names utf8');
?>